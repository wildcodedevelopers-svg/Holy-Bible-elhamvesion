# ELHAM STUDIOS — Sermon Engine Prototype

## Files
- `index.html`: mobile-first Bible reader, local notes/bookmarks, 7-day plan, sermon UI and local outline fallback.
- `server.py`: optional backend for AI-written sermons, Bible Q&A, and a configurable non-Google voice endpoint.
- `requirements.txt`: Python dependencies.

## Important truth about what works
- The Bible reader fetches KJV or WEB from bible-api.com and therefore needs internet.
- Notes, bookmarks, and plan progress are saved in the current browser/device using localStorage.
- With no backend, the sermon button creates a clearly labelled *local starter outline*, not an AI-generated 15-minute sermon.
- Full AI sermon writing and Q&A require an OpenAI-compatible chat-completions backend and credentials.
- Natural audio requires a separate licensed non-Google TTS endpoint that accepts `POST` JSON `{ "text": "...", "voice": "..." }` and returns audio bytes. This is deliberately not wired to browser speech synthesis or Google TTS.
- No credentials belong in `index.html` or a public GitHub repository.
- The default KJV and WEB choices are intended to avoid requiring a paid modern translation licence; check the terms applicable to your jurisdiction and distribution.

## Run locally
1. Install Python 3.10+.
2. In this folder, run `pip install -r requirements.txt`.
3. Configure environment variables for your chosen provider:
   - `LLM_BASE_URL`: base URL ending before `/chat/completions` (example format depends on your provider).
   - `LLM_API_KEY`: secret API key.
   - `LLM_MODEL`: exact model identifier enabled for your account.
   - Optional `TTS_API_URL`: endpoint that accepts `{text, voice}` JSON and returns audio bytes.
   - Optional `TTS_API_KEY`: secret key for that voice service.
4. Run `python server.py`.
5. Open `http://localhost:8000` only if you also serve `index.html` from Flask. This sample server exposes API routes only, so for testing with the static HTML, host the HTML on a local static server and configure same-origin proxying, or serve the HTML via your hosting setup. On a deployment, route `/api/*` to this backend and serve `index.html` from the same origin.

## Deploying
GitHub Pages can host `index.html` only; it cannot run `server.py`. Use a separate backend host and configure a same-origin reverse proxy or update the API base URL in the HTML to your backend origin (and enable CORS there). Do not add secrets to GitHub. Free tiers and free API quotas can change, sleep, or be rate-limited.

## Preacher profiles
The profiles describe broad communication qualities only. They do not clone or claim to reproduce Philip Anthony Mitchell or Billy Graham. Use authorised recordings or licensed voice models if you later add a real person's voice.
